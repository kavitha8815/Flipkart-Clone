document.addEventListener("DOMContentLoaded", function()
{
    console.log("script is loaded and running");
const BeautyProducts = [
    {
        Brand :"Lakme" ,
        image:"https://rukminim2.flixcart.com/image/612/612/xif0q/kajal/s/o/o/0-35-9-to-5-eyeconic-kajal-twin-pack-lasts-upto-24hrs-pack-of-2-original-imagxqbnmmc2gypk.jpeg?q=70" ,
        name: "Lakme 9 to 5 iconic Kajal",
        price: 199,

    },
    {
        Brand : "Ghar soaps",
        image: "https://rukminim2.flixcart.com/image/612/612/xif0q/soap/x/b/i/2-200-sandal-wood-and-saffron-soap-for-glowing-refreshing-skin-original-imah6qnncycfk4qa.jpeg?q=70",
        name: "Sandalwood soap",
        price: 277,
    },
    {
        Brand : "Minara",
        image: "https://rukminim2.flixcart.com/image/612/612/xif0q/brush-applicator/s/t/p/-original-imagzn6z4negxett.jpeg?q=70",
        name: "Make up brush",
        price: 179,

    },
    {
        Brand : "Himalaya",
        image: "https://rukminim2.flixcart.com/image/612/612/xif0q/pedicure-kit/r/e/e/50-20-urea-foot-roll-on-for-dry-cracked-heels-be-bodywise-1-original-imah89etqhkvwfvz.jpeg?q=70",
        name: "Body wise for cracked foor",
        price: 289,

    },
    {
        Brand : "G4U",
        image: "https://rukminim2.flixcart.com/image/612/612/xif0q/nail-polish/p/j/b/24-nail-polish-set-4-colors-red-bromauve-wine-nail-paints-16-18-original-imah7z78p9d7fbv7.jpeg?q=70",
        name: "nailpolish set color nails",
        price: 599,

    },
    {
        Brand : "Hilkamala",
        image: "https://rukminim2.flixcart.com/image/612/612/ktszgy80/foot-filer/a/h/o/foot-file-set-dead-hard-skin-callus-remover-scraper-pedicure-original-imag72ecedcyhpdz.jpeg?q=70",
        name: "Hard skin callus removal",
        price: 299,

    },
    {
        Brand : "Nivea",
        image: "https://rukminim2.flixcart.com/image/612/612/xif0q/moisturizer-cream/u/2/9/-original-imagxyfdggfqqufv.jpeg?q=70",
        name: "Nivea soft cold cream",
        price: 331,

    },
    {
        Brand : "NIMSON",
        image: "https://rukminim2.flixcart.com/image/612/612/xif0q/face-wash/5/o/r/200-glycerine-skin-brightening-face-cleanser-glow-skin-glycerin-original-imah2bytfejpqymc.jpeg?q=70",
        name: "Glycerine",
        price: 184,

    },
    {
        Brand : "Dabur",
        image: "https://rukminim2.flixcart.com/image/612/612/xif0q/hair-oil/f/0/9/-original-imah878zjfvvzezh.jpeg?q=70",
        name: "Almond Hair oil",
        price: 349,

    },
    {
        Brand : "Garuda ",
        image: "https://rukminim2.flixcart.com/image/612/612/xif0q/combo-kit/r/s/x/beardinator-basics-beard-growth-oil-50ml-beard-activator-derma-original-imags7r9538bj4hj.jpeg?q=70",
        name: "Garuda store beard",
        price: 190,

    },
   
];
const BeautyProd = document.getElementById("Beauty-container");
console.log(BeautyProducts);
if(!BeautyProd)
{
    console.error("Product not found");
    return;
}

BeautyProducts.forEach(product =>
{
    const productDiv = document.createElement("div");
    productDiv.className = "product";

    const productImage = document.createElement("img");
    productImage.src = product.image;
    productImage.alt = product.name;
    productDiv.appendChild(productImage);

    const productTitle = document.createElement("p");
    productTitle.className = "name",
    productTitle.textContent = product.name;
    productDiv.appendChild(productTitle);

    const productPrice = document.createElement("p");
    productPrice.className = "price";
    productPrice.textContent = `₹ ${product.price}`;
    productDiv.appendChild(productPrice);

    const buttonContainer = document.createElement("div");
    buttonContainer.className = "product-buttons";

    const addToCartButton = document.createElement("button");
    addToCartButton.textContent = "Add to Cart";
    addToCartButton.addEventListener("click", () =>
    {
        alert(`Added ${product.name} to cart!`);
    });
    buttonContainer.appendChild(addToCartButton);

    const buyNowButton = document.createElement("button");
    buyNowButton.textContent = "Buy Now";
    buyNowButton.addEventListener("click", () =>
    {
        alert(`Proceeding to buy ${product.name}`)
    });
    buttonContainer.appendChild(buyNowButton);

    // buttonContainer.appendChild(addToCartButton);
    // buttonContainer.appendChild(buyNowButton);

    // productDiv.appendChild(productImage);
    // productDiv.appendChild(productPrice);
    // productDiv.appendChild(productTitle);
    productDiv.appendChild(buttonContainer);
    BeautyProd.appendChild(productDiv);


});
});