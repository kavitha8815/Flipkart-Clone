document.addEventListener("DOMContentLoaded", function()
{
    console.log("script is loaded and running");
const babyProducts = [
    {
        Brand : "PURNAKAMAY TRENDZ",
        image: "https://rukminim2.flixcart.com/image/612/612/xif0q/kids-apparel-combo/b/7/c/9-12-months-specialpink01-fiera-fashion-original-imah6ekuh6rhzdfm.jpeg?q=70",
        name: "Girls Middi",
        price: 567,

    },
    {
        Brand : "TRENDZ",
        image: "https://rukminim2.flixcart.com/image/612/612/xif0q/kids-dress/l/o/u/18-24-months-dnpp-hipposippo-original-imah2hxxy7bjtrgm.jpeg?q=70",
        name: "Disney Princess",
        price: 459,

    },
    {
        Brand : "PTRENDZ",
        image: "https://rukminim2.flixcart.com/image/612/612/xif0q/kids-apparel-combo/f/7/m/4-5-years-kdst1-whbl-kdst2-afwh-kdst11-whmt-helpom-original-imagkbhw7rqem3zu.jpeg?q=70",
        name: "Boys casual",
        price: 499,

    },
    {
        Brand : "PUTRENDZ",
        image: "https://rukminim2.flixcart.com/image/612/612/xif0q/kids-apparel-combo/h/o/7/6-12-months-sp-froquiliz-original-imagqe43xn5hyftj.jpeg?q=70",
        name: "Boys Party wear",
        price: 419,

    },
    {
        Brand : "PTrends",
        image: "https://rukminim2.flixcart.com/image/612/612/xif0q/kids-dress/h/j/d/0-3-months-side-strap-net-lm-fashion-original-imah3gvvzcvnhshg.jpeg?q=70",
        name: "Sleeveless Gown",
        price: 219,

    },
    {
        Brand : "PURNAKAMAY TRENDZ",
        image: "https://rukminim2.flixcart.com/image/612/612/xif0q/kids-lehenga-choli/f/e/c/12-18-months-redd-south-indian-pavadai-pattu-lehenga-wommaniya-original-imagpf2ssffufgp8.jpeg?q=70",
        name: "Lehanga",
        price: 1099,

    },
    {
        Brand : "PURNAKAMAY TRENDZ",
        image: "https://rukminim2.flixcart.com/image/612/612/xif0q/kids-lehenga-choli/b/k/s/5-6-years-wine-south-indian-pavadai-pattu-lehenga-wommaniya-original-imah2hgwpznyfnv5.jpeg?q=70",
        name: "Lehanga",
        price: 1099,

    },
    {
        Brand : "PURNAKAMAY TRENDZ",
        image: "https://rukminim2.flixcart.com/image/612/612/xif0q/kids-dress/x/a/a/2-3-years-mira-polka-doted-kids-frock-baby-girl-party-wearfrock-original-imagfmbphzkahw4d.jpeg?q=70",
        name: "Lehanga",
        price: 999,

    },
    {
        Brand : "PURNAKAMAY TRENDZ",
        image: "https://rukminim2.flixcart.com/image/612/612/xif0q/kids-ethnic-set/5/o/3/1-2-years-kurta-and-dhoti-set-for-kids-boys-efl-fashion-original-imah7rsmeebeffpy.jpeg?q=70",
        name: "Lehanga",
        price: 899,

    },
];
const babyProd = document.getElementById("baby-container");
console.log(babyProd);
if(!babyProd)
{
    console.error("Product not found");
    return;
}

babyProducts.forEach(product =>
{
    const productDiv = document.createElement("div");
    productDiv.className = "product";

    const productImage = document.createElement("img");
    productImage.src = product.image;
    productImage.alt = product.name;
    productDiv.appendChild(productImage);

    const productTitle = document.createElement("p");
    productTitle.className = "name",
    productTitle.textContent = product.name;
    productDiv.appendChild(productTitle);

    const productPrice = document.createElement("p");
    productPrice.className = "price";
    productPrice.textContent = `₹ ${product.price}`;
    productDiv.appendChild(productPrice);

    const buttonContainer = document.createElement("div");
    buttonContainer.className = "product-buttons";

    const addToCartButton = document.createElement("button");
    addToCartButton.textContent = "Add to Cart";
    addToCartButton.addEventListener("click", () =>
    {
        alert(`Added ${product.name} to cart!`);
    });
    buttonContainer.appendChild(addToCartButton);

    const buyNowButton = document.createElement("button");
    buyNowButton.textContent = "Buy Now";
    buyNowButton.addEventListener("click", () =>
    {
        alert(`Proceeding to buy ${product.name}`)
    });
    buttonContainer.appendChild(buyNowButton);

    // buttonContainer.appendChild(addToCartButton);
    // buttonContainer.appendChild(buyNowButton);

    // productDiv.appendChild(productImage);
    // productDiv.appendChild(productPrice);
    // productDiv.appendChild(productTitle);
    productDiv.appendChild(buttonContainer);
    babyProd.appendChild(productDiv);


});
});