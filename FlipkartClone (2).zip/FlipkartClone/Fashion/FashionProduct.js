document.addEventListener("DOMContentLoaded", function()
{
    console.log("script is loaded and running");
const sample_data = [
    {
        Brand: "Puma",
        image: "https://rukminim2.flixcart.com/image/612/612/xif0q/track-suit/n/m/e/m-int-ts-203-f-ns1-r-l-bk-integriti-original-imaggaqsqaqj5pyu.jpeg?q=70",
        name: "Men Slim Fit Self",
        price: 558,
        actualprice: 1399
    },
    {
        Brand: "Arrow",
        image: "https://rukminim2.flixcart.com/image/612/612/xif0q/shirt/s/4/f/-original-imagsfejwcyfa4yx.jpeg?q=70",
        name: "Men Slim Fit Self",
        price: 2028,
        actualprice: 2899
    },
    {
        Brand: "ZONANZA",
        image: "https://rukminim2.flixcart.com/image/612/612/xif0q/shirt/m/l/c/l-mens-striped-floral-printed-lycra-solid-stylish-casual-shirts-original-imagmwzgfkuyggdy.jpeg?q=70",
        price: 307,
        actualprice:1299 ,
        name:  "MENS SHIRT"

    },
    {
        Brand: "SEVENTEENSTITCH",
        image: "https://rukminim2.flixcart.com/image/612/612/xif0q/shirt/p/s/q/m-sv0063-jihan-enterprise-original-imagkxcphckm6wfv.jpeg?q=70",
        price: 299,
        actualprice: 1200,
        name:  "SHIRT"

    },
    {
        Brand: "Shree Mahalaxmi ",
        image: "https://rukminim2.flixcart.com/image/612/612/xif0q/ethnic-set/n/z/i/xxl-wine0-subhla-art-original-imahyctth5r9zmha.jpeg?q=70",
        name:  "Kurta Pant Dupatta",
        price: 569,
        actualprice: 999

    },
    {
        Brand: "Shree Mahalaxmi ",
        image: "https://rukminim2.flixcart.com/image/612/612/xif0q/ethnic-set/8/u/c/m-df-sk-600-demotex-fashion-original-imagt4u7rfbmgqma.jpeg?q=70",
        name:  "Kurta Pant Dupatta",
        price: 1225,
        actualprice: 1599

    },
    {
        Brand: "Shree Mahalaxmi ",
        image: "https://rukminim2.flixcart.com/image/612/612/xif0q/sari/8/m/f/free-galaxy-silver-patti-light-grey-d-aadishakti-fashion-original-imagxffxxtedcdzc.jpeg?q=70",
        price: 411,
        actualprice: 3999,
        name:  "Kurta Pant"

    },
    {
        Brand: "Jash Creation",
        image: "https://rukminim2.flixcart.com/image/612/612/xif0q/gown/8/u/a/na-xxl-3-4-sleeve-stitched-ss0095-femvy-na-original-imagwsfh4q5aygmy.jpeg?q=70",
        price: 229,
        actualprice: 500,
        name:  "Long Top"

    },
    {
        Brand: "VERO MODA",
        image: "https://rukminim2.flixcart.com/image/612/612/l02r1jk0/t-shirt/g/6/z/xs-275325701-vero-moda-original-imagby2gkzrnkzks.jpeg?q=70",
        price: 459,
        actualprice: 999,
        name:  "Women Typo"

    },
    {
        Brand: "CHOZI",
        image: "https://rukminim2.flixcart.com/image/612/612/xif0q/t-shirt/m/t/x/s-combo774-chozi-original-imah78qvycnzgq9v.jpeg?q=70",
        price: 459,
        actualprice: 899,
        name:  "Women night t-shirts"

    },
  
];

const productContainer = document.getElementById("product-container");
if(!productContainer)
{
    console.error("Product container not found");
    return;
}
sample_data.forEach(product => {
    const productDiv = document.createElement("div");
    productDiv.className = "product";

    const productImage = document.createElement("img");
    productImage.src = product.image;
    productImage.alt = product.name;

    const productTitle = document.createElement("p");
    productTitle.className = "name";
    productTitle.textContent = product.name;

    const productPrice = document.createElement("p");
    productPrice.className = "price";
    productPrice.textContent = `₹ ${product.price}`;

    const buttonContainer = document.createElement("div");
    buttonContainer.className = "product-buttons";

    const addToCartButton = document.createElement("button");
    addToCartButton.textContent = "Add to cart";
    addToCartButton.addEventListener("click", () =>{
      alert(`Added ${product.name} to cart!`);   
    });
    const buyNowButton = document.createElement("button");
    buyNowButton.textContent = "Buy Now";
    buyNowButton.addEventListener("click", () =>{
        alert(`Proceeding to buy ${product.name}!`);
    });

    buttonContainer.appendChild(addToCartButton); 
    buttonContainer.appendChild(buyNowButton);

    productDiv.appendChild(productImage);
    productDiv.appendChild(productPrice)
    productDiv.appendChild(productTitle);
    productDiv.appendChild(buttonContainer);
    productContainer.appendChild(productDiv);
 });
});
