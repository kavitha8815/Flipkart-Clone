document.addEventListener("DOMContentLoaded", function()
{
    console.log("script is loaded and running");
const HomeProducts = [
    {
        Brand : "Prestige",
        image: "https://rukminim2.flixcart.com/image/612/612/xif0q/hand-blender/a/k/m/pureblend-classic-bdpb-cl40150-salt-original-imah383xas2c6egb.jpeg?q=70",
        name: "Hand Blender",
        price: 599,

    },
    {
        Brand : "Prestige",
        image: "https://rukminim2.flixcart.com/image/612/612/xif0q/food-maker/e/c/y/magic-chapati-e-10-m-10-roti-khakhra-maker-gi-shop-original-imah7krhhhxbhse5.jpeg?q=70",
        name: "Roti maker",
        price: 1300,

    },
    {
        Brand : "Butterfly",
        image: "https://rukminim2.flixcart.com/image/612/612/ku79vgw0/electric-kettle/p/a/o/combo-set-insta-electric-stainless-steel-kettle-1-5-litres-original-imag7dtqbt28th2k.jpeg?q=70",
        name: "Kettle",
        price: 1000,

    },
    {
        Brand : "Maha lakshmi",
        image: "https://rukminim2.flixcart.com/image/612/612/xif0q/mixer-grinder-juicer/y/b/z/citrus-juicer-buyerzone-original-imah7y3yaukwm5xw.jpeg?q=70",
        name: "Juicer",
        price: 1500,

    },
    {
        Brand : "Electric Hand blender",
        image: "https://rukminim2.flixcart.com/image/612/612/xif0q/shopsy-kitchen-tool-set/a/l/j/unique-impex-electric-hand-blender-egg-beater-egg-mixer-cake-original-imagtdkfcahzjffa.jpeg?q=70",
        name: "Hand blender electric",
        price: 499,

    },
    {
        Brand : "LV pure",
        image: "https://rukminim2.flixcart.com/image/612/612/xif0q/water-purifier/o/o/q/-original-imah2hq8g7pdhggz.jpeg?q=70",
        name: "Water purifier",
        price: 9999,

    },
    {
        Brand : "Wipro Elato",
        image: "https://rukminim2.flixcart.com/image/612/612/xif0q/iron/j/r/k/vesta-lightweight-automatic-quick-heat-up-stylish-sleek-2-years-original-imaghj3zgssjhmg7.jpeg?q=70",
        name: "Iron box",
        price: 1499,

    },
    {
        Brand : "Eco Bubble",
        image: "https://rukminim2.flixcart.com/image/612/612/xif0q/washing-machine-new/s/p/9/-original-imahfs4fuqqfgacf.jpeg?q=70",
        name: "Washing Machine",
        price: 29999,

    },
    {
        Brand : "Axmon",
        image: "https://rukminim2.flixcart.com/image/612/612/xif0q/immersion-rod/n/j/d/1500-shock-proof-water-proof-1500-w-immersion-rod-water-heater-original-imah4hf6tyjfje5h.jpeg?q=70",
        name: "Heater",
        price: 999,

    },
];
const HomeProd = document.getElementById("home-container");
console.log(HomeProducts);
if(!HomeProd)
{
    console.error("Product not found");
    return;
}

HomeProducts.forEach(product =>
{
    const productDiv = document.createElement("div");
    productDiv.className = "product";

    const productImage = document.createElement("img");
    productImage.src = product.image;
    productImage.alt = product.name;
    productDiv.appendChild(productImage);

    const productTitle = document.createElement("p");
    productTitle.className = "name",
    productTitle.textContent = product.name;
    productDiv.appendChild(productTitle);

    const productPrice = document.createElement("p");
    productPrice.className = "price";
    productPrice.textContent = `₹ ${product.price}`;
    productDiv.appendChild(productPrice);

    const buttonContainer = document.createElement("div");
    buttonContainer.className = "product-buttons";

    const addToCartButton = document.createElement("button");
    addToCartButton.textContent = "Add to Cart";
    addToCartButton.addEventListener("click", () =>
    {
        alert(`Added ${product.name} to cart!`);
    });
    buttonContainer.appendChild(addToCartButton);

    const buyNowButton = document.createElement("button");
    buyNowButton.textContent = "Buy Now";
    buyNowButton.addEventListener("click", () =>
    {
        alert(`Proceeding to buy ${product.name}`)
    });
    buttonContainer.appendChild(buyNowButton);

    // buttonContainer.appendChild(addToCartButton);
    // buttonContainer.appendChild(buyNowButton);

    // productDiv.appendChild(productImage);
    // productDiv.appendChild(productPrice);
    // productDiv.appendChild(productTitle);
    productDiv.appendChild(buttonContainer);
    HomeProd.appendChild(productDiv);


});
});