let currentSlide = 0;
const carouselItems =  document.querySelectorAll('.carousel-item');
 
function moveSlide(index)
{
    carouselItems.forEach(item, i=> {
        item.style.transform = `translateX(${100 * (i- index)}%)`;
    });
    currentSlide = index;
}

setInterval(() => {
const nextSlide = (currentSlide + 1) % carouselItems.length;
moveSlide(nextSlide);
}, 5000);