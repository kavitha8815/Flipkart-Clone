document.addEventListener("DOMContentLoaded", () =>
{
const categories = [
    {
        img: " https://rukminim2.flixcart.com/flap/128/128/image/50474c.jpg?q=100 ",
        title: "Grocery",
        link: "http://127.0.0.1:5500/Grocery/GroceryNavBar.html"
       
    },
    {
        img:
          "https://rukminim1.flixcart.com/fk-p-flap/128/128/image/0d75b34f7d8fbcb3.png?q=100",
        title: "Fashion",
        link: "http://127.0.0.1:5500/Fashion/FashionProduct.html"
        
    },
      
    {
        img:
          "https://rukminim1.flixcart.com/flap/80/80/image/69c6589653afdb9a.png?q=100",
        title: "Electronics",
        link:"http://127.0.0.1:5500/Electronics/ElectronicProd.html"
    },
    {
        img:
          "https://rukminim1.flixcart.com/flap/80/80/image/0ff199d1bd27eb98.png?q=100",
        title: "Home Appliances",
        link:"http://127.0.0.1:5500/HomeandAppliances/HomeAppliances.html"
    },
    {
      img:
        "https://rukminim1.flixcart.com/flap/80/80/image/ab7e2b022a4587dd.jpg?q=100",
      title: "Home and Furtinure",
      link:"http://127.0.0.1:5500/HomeandFurniture/HomeFurniture.html"
    },
    {
        img:
          "https://external-content.duckduckgo.com/iu/?u=https%3A%2F%2Ftse3.mm.bing.net%2Fth%3Fid%3DOIP.xW-jsi-mJd7p3Bg3z2l7JAAAAA%26pid%3DApi&f=1&ipt=99296798063d17b019664b448e71e1e93440c3ea1d8ef1e15021c4e70eea2377&ipo=images",
        title:  "Sports,Books & More",
        link: "http://127.0.0.1:5500/SportsBooks&MOre/Sports.html"
    },
    {
        img:
          "https://rukminim1.flixcart.com/flap/80/80/image/dff3f7adcf3a90c6.png?q=100",
        title: "Beauty,Toys and More",
        link:"http://127.0.0.1:5500/BeautyToys&More/BeautyToys&More.html"
      
    },
    {
        img:
          "https://external-content.duckduckgo.com/iu/?u=https%3A%2F%2Ftse1.mm.bing.net%2Fth%3Fid%3DOIP.qYUCUkSsiZr5vm7G1ce5SwHaJD%26pid%3DApi&f=1&ipt=cb6f5e989617116ae1e7cc4ffe08112cbb34d6f79a57322f3053cd437b5db9fb&ipo=images",
        title: "Baby & Kids",
        link:"http://127.0.0.1:5500/BabyandKids/BabyandKids.html"
       
    }
  ];
 
  const categoriesContainer = document.getElementById("categories");
  if (!categoriesContainer) {
    console.error("Categories container not found!");
    return;
}
 categories.forEach(category => 
  {
    const categoryLink = document.createElement("a");;
    categoryLink.href = category.link;
    categoryLink.target = "_self";
    categoryLink.style.color = "inherit";

  const categoryDiv = document.createElement("div");
  categoryDiv.classList.add("category-item");

  const categoryImg = document.createElement("img");
  categoryImg.src = category.img;
  categoryImg.alt = category.title; // Add alt text for accessibility
  categoryImg.style.width = "100px"; 

  const categoryTitle = document.createElement("p");
  categoryTitle.textContent = category.title;

  categoryDiv.appendChild(categoryImg);
  categoryDiv.appendChild(categoryTitle);

  categoryLink.appendChild(categoryDiv);

  categoriesContainer.appendChild(categoryLink);
 });

});
       

 