document.addEventListener("DOMContentLoaded", function() 
{
  console.log("script is loaded and running");
const electronicsProd = 
[ 
  
  {
    Brand: "LG",
    // description:"Asus model with 180 degree rotation",
    image: "https://rukminim2.flixcart.com/image/612/612/xif0q/computer/e/m/g/fx706hf-ny040w-gaming-laptop-asus-original-imah4bjbeve36gag.jpeg?q=70",
    name: "Asus Laptop",
    price: 50000,
  },
  {
    Brand: "PHILIPS",
    // description:"Asus model with 180 degree rotation",
    image: "https://rukminim2.flixcart.com/image/612/612/kuof5ow0/trimmer/7/z/f/0-5-10-mm-bt3101-15-stainless-steel-cordless-philips-original-imag7r4r7ztgnuyk.jpeg?q=70",
    name: "Trimmer",
    price: 1199,
  },
  {
    Brand: "SAMSUNG",
    // description:"Asus model with 180 degree rotation",
    image:"https://rukminim2.flixcart.com/image/612/612/xif0q/television/k/h/w/-original-imah3868qdatnqg8.jpeg?q=70",
    name: "Samsung HD TV ",
    price: 13716,
  },
  {
    Brand: "HP",
   
    // description:"HP model with 180 rotation and keypad light",
    image: "https://rukminim2.flixcart.com/image/612/612/xif0q/computer/n/i/7/x1504za-nj521ws-x1504za-nj520ws-thin-and-light-laptop-asus-original-imah4fv4jrrag9dq.jpeg?q=70",
    name: "HP Laptop",
    price: 40000,
  },
  {
    Brand: "Vivobook",
    // description:"Vivobook model with 360 rotation and also finger print sensor to unlock",
    image: "https://rukminim2.flixcart.com/image/612/612/xif0q/computer/b/v/j/-original-imah4e8s3u2cznyv.jpeg?q=70",
    name: "Vivobook Laptop",
    price: 80000,
  },
  {
    Brand:"Boult Air Bass",
    image:"https://rukminim2.flixcart.com/image/612/612/xif0q/headphone/y/y/f/-original-imah4rhakzenu9g4.jpeg?q=70",
    name:"Boult",
    price: 899,
  },
  {
    Brand: "Oneplus nord",
    image:"https://rukminim2.flixcart.com/image/612/612/l4ei1e80/headphone/b/j/w/bullets-wireless-z2-oneplus-original-imagfaww7ga6nshz.jpeg?q=70",
    name:"Oneplus",
    price: 1299,
  },
  {
    Brand: "OMRON",
    image:"https://rukminim2.flixcart.com/image/612/612/xif0q/bp-monitor/w/u/p/omron-hem-7140t1-bluetooth-blood-pressure-monitor-hem-7140t1-original-imah76efyjyx9sdz.jpeg?q=70",
    name:"OMRON BP Machine",
    price: 1749,
  },
  {
    Brand:"Canon",
    image:"https://rukminim2.flixcart.com/image/312/312/jfbfde80/camera/n/r/n/canon-eos-eos-3000d-dslr-original-imaf3t5h9yuyc5zu.jpeg?q=70",
    name:"Canon EOS",
    price:"13999"

  },
  {
    Brand: "Realme",
    image:"https://rukminim2.flixcart.com/image/312/312/xif0q/tablet/o/y/8/rmp2204-realme-original-imagrhcqdhdyc9tg.jpeg?q=70",
    name:"realme pad",
    price: 17999,
  }
];

const ElectronicProd = document.getElementById("electronics-container");
console.log(electronicsProd);
if(!ElectronicProd)
{
    console.error("Product not found");
    return;
}
console.log("Not found");
electronicsProd.forEach(product =>
{
    const productDiv = document.createElement("div");
    productDiv.className = "product";

    const productImage = document.createElement("img");
    productImage.src = product.image;
    productImage.alt = product.name;
    productDiv.appendChild(productImage);

    const productTitle = document.createElement("p");
    productTitle.className = "name",
    productTitle.textContent = product.name;
    productDiv.appendChild(productTitle);
   
    const productPrice = document.createElement("p");
    productPrice.className = "price";
    productPrice.textContent = `₹ ${product.price}`;
    productDiv.appendChild(productPrice);

    const buttonContainer = document.createElement("div");
    buttonContainer.className = "product-buttons";

    const addToCartButton = document.createElement("button");
    addToCartButton.textContent = "Add to Cart";
    addToCartButton.addEventListener("click", () =>
    {
        alert(`Added ${product.name} to cart!`);
    });
    buttonContainer.appendChild(addToCartButton);

    const buyNowButton = document.createElement("button");
    buyNowButton.textContent = "Buy Now";
    buyNowButton.addEventListener("click", () =>
    {
        alert(`Proceeding to buy ${product.name}`)
    });
    buttonContainer.appendChild(buyNowButton);

    // buttonContainer.appendChild(addToCartButton);
    // buttonContainer.appendChild(buyNowButton);

    // productDiv.appendChild(productImage);
    // productDiv.appendChild(productPrice);
    // productDiv.appendChild(productTitle);
    productDiv.appendChild(buttonContainer);
    ElectronicProd.appendChild(productDiv);


});
});
























// const arr = document.getElementById("electronics-container");
// console.log(electronicsProd);
// if(!arr)
// {
//   console.error("Categories container not found");
//   return;
// }
// electronicsProd.forEach(category => {
//   console.log(`Processing category: ${category.name}`);
//   const categoryDiv = document.createElement("div");
//   const categoryTitle = document.createElement("p");
//   categoryTitle.textContent = category.name;

//   const categoryImage = document.createElement("img");
//   categoryImage.src = category.image;
//   categoryImage.alt = category.name;

//   categoryDiv.appendChild(categoryTitle);
//   categoryDiv.appendChild(categoryImage);
//   arr.appendChild(categoryDiv);
//   (categoryDiv); console.log(`Added ${category.name} to categories`);
// });
// });