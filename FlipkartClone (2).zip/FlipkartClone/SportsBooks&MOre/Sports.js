document.addEventListener("DOMContentLoaded", function() 
{
  console.log("script is loaded and running");
const SportsProd = 
[ 
  
  {
   
    image: "https://rukminim2.flixcart.com/image/612/612/book/4/6/8/tell-me-more-original-imadpu3rjmduvzvd.jpeg?q=70",
    name: "Tell me more",
    price: 164,
  },
  {
    image: "https://rukminim2.flixcart.com/image/612/612/xif0q/book/y/m/g/sports-technology-cryotherapy-led-courts-and-more-original-imag7bzeytaaqq63.jpeg?q=70",
    name: "Sport Technology",
    price: 299,
  },
  {
    image: "https://rukminim2.flixcart.com/image/612/612/xif0q/clutch/d/x/2/women-s-and-girls-handclutch-cum-mobile-handbag-ykfc-103-301-original-imahyg5j6ke2ffmv.jpeg?q=70",
    name: "Sports bLue clutch",
    price: 329,
  },
  {
    image: "https://rukminim2.flixcart.com/image/612/612/xif0q/helmet/l/q/m/-original-imagshze3q49rszp.jpeg?q=70",
    name: "Steelbird helmet",
    price: 1629,
  },
  {
    image: "https://rukminim2.flixcart.com/image/612/612/kzn17680/sport-glove/n/o/e/-original-imagbhp7pkpdyc3e.jpeg?q=70",
    name: "Bike touchscreen sensitivity",
    price: 599,
  },
  {
    image: "https://rukminim2.flixcart.com/image/612/612/xif0q/two-wheeler-cover/f/r/p/blcic3501929105-classic-350-fit-fly-original-imah7ctwzwhawtgq.jpeg?q=70",
    name: "Fit Fly water proof cover",
    price: 263,
  },
  {
    image: "https://rukminim2.flixcart.com/image/612/612/xif0q/shopsy-vehicle-washing-cloth/g/b/x/1-micro-towel-chadhaji-original-imah3fejgvetrkjx.jpeg?q=70",
    name: "Vehicle Washing cloth",
    price: 54,
  },
  {
    image: "https://rukminim2.flixcart.com/flap/50/50/image/61ea2962241defbb.jpg?q=50",
    name: "Musical instrument",
    price: 13599,
  },
  {
    image: "https://rukminim2.flixcart.com/image/612/612/xif0q/diary-notebook/s/i/h/morning-glory-morning-glory-doodle-original-imah5f2amzkzxzta.jpeg?q=70",
    name: "Diary",
    price: 299,
  },
  {
    image: "https://rukminim2.flixcart.com/image/612/612/xif0q/kit/p/l/o/wooden-cricket-bat-and-ball-with-4-scoop-design-size-1-ages-3-4-original-imah2gfj2bhuftev.jpeg?q=70",
    name: "Ball and Bat combo",
    price: 499,
  }
 
];

const SportsProducts = document.getElementById("Sports-Container");
console.log(SportsProd);
if(!SportsProducts)
{
    console.error("Product not found");
    return;
}
console.log("Not found");
SportsProd.forEach(product =>
{
    const productDiv = document.createElement("div");
    productDiv.className = "product";

    const productImage = document.createElement("img");
    productImage.src = product.image;
    productImage.alt = product.name;
    productDiv.appendChild(productImage);

    const productTitle = document.createElement("p");
    productTitle.className = "name",
    productTitle.textContent = product.name;
    productDiv.appendChild(productTitle);
   
    const productPrice = document.createElement("p");
    productPrice.className = "price";
    productPrice.textContent = `₹ ${product.price}`;
    productDiv.appendChild(productPrice);

    const buttonContainer = document.createElement("div");
    buttonContainer.className = "product-buttons";

    const addToCartButton = document.createElement("button");
    addToCartButton.textContent = "Add to Cart";
    addToCartButton.addEventListener("click", () =>
    {
        alert(`Added ${product.name} to cart!`);
    });
    buttonContainer.appendChild(addToCartButton);

    const buyNowButton = document.createElement("button");
    buyNowButton.textContent = "Buy Now";
    buyNowButton.addEventListener("click", () =>
    {
        alert(`Proceeding to buy ${product.name}`)
    });
    buttonContainer.appendChild(buyNowButton);

    // buttonContainer.appendChild(addToCartButton);
    // buttonContainer.appendChild(buyNowButton);

    // productDiv.appendChild(productImage);
    // productDiv.appendChild(productPrice);
    // productDiv.appendChild(productTitle);
    productDiv.appendChild(buttonContainer);
    SportsProducts.appendChild(productDiv);


});
});
























