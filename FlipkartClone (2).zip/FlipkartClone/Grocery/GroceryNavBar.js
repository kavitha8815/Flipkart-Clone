document.addEventListener("DOMContentLoaded", function(){
console.log("Script is loaded and running");
let groceryProducts=[
    {
        Brand:"SiddiVinayak Egg Container",
        image: "https://rukminim2.flixcart.com/flap/128/128/image/8014b1.jpg?q=100",
        title: "Egg Container",
        price: 250,
    },
    {   
        Brand:"Saffola masala oats",
        image: "https://rukminim2.flixcart.com/flap/128/128/image/ac8550.jpg?q=100",
        title: "Packaged Food",
        price: 199,
    },
    {
        Brand:"Cadbury",
        image: "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRys8sItxhxQbFu_92pss13GwC4s2dcfwIgZ3q8PXogzuefmlHUT2c1yUH8OlmaAb6PSzA&usqp=CAU",
        title: "Chocolates and Biscuits",
        price: 149,
    },
    {
        Brand:"Nescafe",
        image: "https://rukminim2.flixcart.com/image/280/280/xif0q/coffee/g/b/3/-original-imah3adkrm4gy2rz.jpeg?q=70",
        title: "Coffee Powder",
        price: 299,
    },
    {
        Brand:"Haldiram Soan papidi",
        image: "https://rukminim2.flixcart.com/image/612/612/ke5zzbk0/sweet-mithai/t/h/h/1-soan-papdi-multi-flavour-ganesh-keychain-soan-papdi-haldiram-s-original-imafuxyt448k2zzx.jpeg?q=70",
        title: "Snacks & Beverages",
        price: 145,
    },
    { 
        Brand:"Pepsi",
        image: "https://rukminim2.flixcart.com/image/612/612/xif0q/aerated-drink/t/h/y/330-soft-drink-tin-1-pepsi-original-imah45gwzdz5b3fg.jpeg?q=70",
        title: "Drinks",
        price: 40,
    },
    {
        Brand:"BLK Foods",
        image:"https://rukminim2.flixcart.com/image/612/612/xif0q/nut-dry-fruit/f/u/n/200-select-walnut-kernels-kashmiri-light-halves-1-pouch-blk-original-imah4j32hbnzn2gj.jpeg?q=70",
        title:"Walnuts",
        price: 1000,
    },
    {
        Brand: "INDIA GATE",
        image:"https://rukminim2.flixcart.com/image/612/612/xif0q/rice/y/9/z/-original-imah3h5yus838s8v.jpeg?q=70",
        title: "India Gate Basmati Rice",
        price: 587,
    },
    {
        Brand:"Prestige",
        image: "https://rukminim2.flixcart.com/image/612/612/xif0q/induction-cook-top/f/n/u/atlas-3-0-plus-atlas-3-0-plus-prestige-original-imah8bhyh6ganaqh.jpeg?q=70",
        title: "Home & Kitchen",
        price: 1599,
    }, 
];
const GroceryProd = document.getElementById("grocery-Container");
console.log(groceryProducts);
if(!GroceryProd)
{
    console.error("Products not found");
    return;
}
groceryProducts.forEach(product =>
{
    const productDiv = document.createElement("div");
    productDiv.className = "product";

    const productImage = document.createElement("img");
    productImage.src = product.image;
    productImage.alt = product.name;
    productDiv.appendChild(productImage);

    const productTitle = document.createElement("p");
    productTitle.className = "name",
    productTitle.textContent = product.name;
    productDiv.appendChild(productTitle);

    const productPrice = document.createElement("p");
    productPrice.className = "price";
    productPrice.textContent = `₹ ${product.price}`;
    productDiv.appendChild(productPrice);

    const buttonContainer = document.createElement("div");
    buttonContainer.className = "product-buttons";

    const addToCartButton = document.createElement("button");
    addToCartButton.textContent = "Add to Cart";
    addToCartButton.addEventListener("click", () =>
    {
        alert(`Added ${product.name} to cart!`);
    });
    buttonContainer.appendChild(addToCartButton);

    const buyNowButton = document.createElement("button");
    buyNowButton.textContent = "Buy Now";
    buyNowButton.addEventListener("click", () =>
    {
        alert(`Proceeding to buy ${product.name}`)
    });
    buttonContainer.appendChild(buyNowButton);
    productDiv.appendChild(buttonContainer);
    GroceryProd.appendChild(productDiv);
});
});
 