document.addEventListener("DOMContentLoaded", () =>{

let arr=[
    {
        title:"Electronics",
    },
    {
        title:"Tv & appliances",
    },
    {
        title:"Fashion",
    },
    {
       title:"Baby & Kids", 
    },
    {
        title:"Home & Furniture",
    }
];

const arrContainer =  document.getElementById("arr");
if(!arrContainer){
    console.error("Categories Conatiner not found");
    return;
}
arr.forEach(category => {
    const categoryDiv = document.creatElement("div");
    const categoryTitle = document.createElement("p");
    categoryTitle.textContent = category.title;

    categoryDiv.appendChild(CategoryTitle);
    arrContainer.appendChild(categoryDiv);
});
});