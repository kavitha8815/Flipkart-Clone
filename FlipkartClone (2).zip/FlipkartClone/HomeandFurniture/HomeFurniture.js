document.addEventListener("DOMContentLoaded", function()
{
    console.log("script is loaded and running");
const FurnitureProducts = [
    {
        Brand : "Rumps",
        image: "https://rukminim2.flixcart.com/image/612/612/xif0q/bedsheet/l/y/s/presents-luxurious-bedsheets-for-winter-king-size-fitted-flannel-original-imah6vh7j97e2uyd.jpeg?q=70",
        name: "Bed Sheet",
        price: 579,

    },
    {
        Brand : "TENFIT",
        image: "https://rukminim2.flixcart.com/image/612/612/xif0q/diwan-set/k/q/j/mvtc-01g-14-maniqatex-original-imahfy3hh25fzy9d.jpeg?q=70",
        name: "Diwan sets",
        price: 599,
    },
    {
        Brand : "Home Sizzler",
        image: "https://rukminim2.flixcart.com/image/612/612/kzk6bgw0/curtain/c/a/g/digital-print-153-hs1pc001161wd-window-eyelet-home-sizzler-original-imagbjdeeyyag7hx.jpeg?q=70",
        name: "Home Sizzler polyster",
        price: 225,

    },
    {
        Brand : "G Fabrics",
        image: "https://rukminim2.flixcart.com/image/612/612/ktyp8cw0/bath-towel/f/j/o/pure-cotton-soft-smooth-stretchy-towel-quickly-absorbing-water-original-imag774gxrppt6pw.jpeg?q=70",
        name: "Bath towel",
        price: 174,

    },
    {
        Brand : "Nabaat Micro Oven cover",
        image: "https://rukminim2.flixcart.com/image/612/612/xif0q/appliance-cover/7/x/f/1-100-oc-bk-1-nabaat-35-original-imah6yzetj3t3qgd.jpeg?q=70",
        name: "Micro oven cover",
        price: 259,

    },
    {
        Brand : "Homestic refrigerator ",
        image: "https://rukminim2.flixcart.com/image/612/612/xif0q/appliance-cover/y/j/w/95-56-51ht02137-homestic-1-original-imah45h7yndthuqd.jpeg?q=70",
        name:"Refrigerator cover",
        price: 9999,

    },
    {
        Brand : "Turtle Grip Fibre",
        image: "https://rukminim2.flixcart.com/image/612/612/xif0q/mosquito-net/3/b/h/door-120-gsm-fiberglass-magnetic-door-0-welbng-fg-gy200-90-original-imagh8bpmafjbe98.jpeg?q=70",
        name: "washable Fibrelee Glass",
        price: 899,

    },
    {
        Brand : "Nabaat Micro Oven cover",
        image: "https://rukminim2.flixcart.com/image/612/612/xif0q/appliance-cover/7/x/f/1-100-oc-bk-1-nabaat-35-original-imah6yzetj3t3qgd.jpeg?q=70",
        name: "Micro oven cover",
        price: 259,

    },
    {
        Brand : "G Fabrics",
        image: "https://rukminim2.flixcart.com/image/612/612/kazor680/bath-towel/w/w/y/100-cotton-king-size-bath-towels-set-of-2pcs-bath-towel-3-vel-original-imafsfwfxmyzhw8u.jpeg?q=70",
        name: "towel",
        price: 174,

    },
    {
        Brand : "Nylon",
        image: "https://rukminim2.flixcart.com/image/612/612/xif0q/shopsy-mat/n/c/o/medium-round-dori-1-r-m-025-ki-home-original-imagzdd3ewzrzxch.jpeg?q=70",
        name: "Door mats",
        price: 174,

    },
    {
        Brand : "G Fabric",
        image: "https://rukminim2.flixcart.com/image/612/612/l3hmwsw0/pillow/b/z/t/cushion-filler-shcf1616so5wh-sleepyhead-original-imagehd4gsh8rkyg.jpeg?q=70",
        name: "Pillows",
        price: 174,

    },
    {
        Brand : "Fabrics",
        image: "https://rukminim2.flixcart.com/image/612/612/xif0q/pillow/o/j/b/27-5-wedge-pillow-1-sl697-sleepsia-original-imah86z7hdd5hfnp.jpeg?q=70",
        name: "Sleepisa Bed widge pillow",
        price: 174,

    },
    // {
    //     Brand : "Eco Bubble",
    //     image: "",
    //     name: "Washing Machine",
    //     price: 29999,

    // },
    // {
    //     Brand : "Axmon",
    //     image: "",
    //     name: "Heater",
    //     price: 999,

    // },
];
const FurnProd = document.getElementById("Furniture-container");
console.log(FurnitureProducts);
if(!FurnProd)
{
    console.error("Product not found");
    return;
}

FurnitureProducts.forEach(product =>
{
    const productDiv = document.createElement("div");
    productDiv.className = "product";

    const productImage = document.createElement("img");
    productImage.src = product.image;
    productImage.alt = product.name;
    productDiv.appendChild(productImage);

    const productTitle = document.createElement("p");
    productTitle.className = "name",
    productTitle.textContent = product.name;
    productDiv.appendChild(productTitle);

    const productPrice = document.createElement("p");
    productPrice.className = "price";
    productPrice.textContent = `₹ ${product.price}`;
    productDiv.appendChild(productPrice);

    const buttonContainer = document.createElement("div");
    buttonContainer.className = "product-buttons";

    const addToCartButton = document.createElement("button");
    addToCartButton.textContent = "Add to Cart";
    addToCartButton.addEventListener("click", () =>
    {
        alert(`Added ${product.name} to cart!`);
    });
    buttonContainer.appendChild(addToCartButton);

    const buyNowButton = document.createElement("button");
    buyNowButton.textContent = "Buy Now";
    buyNowButton.addEventListener("click", () =>
    {
        alert(`Proceeding to buy ${product.name}`)
    });
    buttonContainer.appendChild(buyNowButton);

    // buttonContainer.appendChild(addToCartButton);
    // buttonContainer.appendChild(buyNowButton);

    // productDiv.appendChild(productImage);
    // productDiv.appendChild(productPrice);
    // productDiv.appendChild(productTitle);
    productDiv.appendChild(buttonContainer);
    FurnProd.appendChild(productDiv);


});
});